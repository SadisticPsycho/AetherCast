# AetherCast

Personal low-latency screen casting from Android phone → Xiaomi Google TV.

## Current Status (honest)

**What is working / ready:**
- Beautiful modern dark UI on the phone (Compose)
- Quality presets + audio toggle
- Screen capture service with MediaProjection
- Local signaling server (NanoHTTPD on port 8080)
- PIN generation + local IP detection
- WebRTC PeerConnection factory + offer creation
- Receiver UI that can talk to the phone’s signaling server
- Full project structure ready for GitHub + Codespaces build

**What still needs the final glue:**
- Attaching the VirtualDisplay surface to WebRTC VideoSource (actual frame pipeline)
- Complete answer + ICE candidate exchange
- Video rendering on the TV (SurfaceViewRenderer)
- Live state updates in the phone UI from the service

This is a strong, well-structured foundation. The architectural pieces are in place. The remaining work is connecting the final pipes so video actually appears.

## How to build

1. Upload the whole `AetherCast` folder to a new GitHub repo.
2. Open Codespaces (free).
3. Inside the codespace:

```bash
cd sender
./gradlew assembleDebug

cd ../receiver
./gradlew assembleDebug
```

APKs will be in the `app/build/outputs/apk/debug/` folders.

## Project structure

```
AetherCast/
├── sender/     ← Phone app
├── receiver/   ← TV app
└── README.md
```

## Next

If you want me to finish the remaining video pipeline so it actually streams, just say **“finish the video pipeline”**.
