package com.aethercast.receiver

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF7C5CFF),
                    background = Color(0xFF0A0A0E),
                    surface = Color(0xFF14141A)
                )
            ) {
                ReceiverScreen()
            }
        }
    }
}

@Composable
fun ReceiverScreen() {
    var pinInput by remember { mutableStateOf("") }
    var phoneIp by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Enter phone IP + PIN from the notification") }
    var isConnecting by remember { mutableStateOf(false) }
    var isConnected by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A0E)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = "AetherCast",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF7C5CFF)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = status,
                fontSize = 18.sp,
                color = Color.White.copy(alpha = 0.75f)
            )

            Spacer(modifier = Modifier.height(40.dp))

            if (!isConnected) {
                OutlinedTextField(
                    value = phoneIp,
                    onValueChange = { phoneIp = it },
                    label = { Text("Phone IP address") },
                    placeholder = { Text("192.168.x.x") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(0.7f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF7C5CFF),
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { if (it.length <= 6) pinInput = it },
                    label = { Text("6-digit PIN") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(0.7f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5A8),
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = {
                        if (phoneIp.isNotBlank() && pinInput.length == 6) {
                            isConnecting = true
                            status = "Connecting…"
                            scope.launch {
                                val success = connectToPhone(phoneIp.trim(), pinInput)
                                isConnecting = false
                                if (success) {
                                    isConnected = true
                                    status = "Signaling OK – full video pipeline coming next"
                                } else {
                                    status = "Failed – check IP, PIN and same network"
                                }
                            }
                        }
                    },
                    enabled = !isConnecting && phoneIp.isNotBlank() && pinInput.length == 6,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text(if (isConnecting) "Connecting…" else "Connect", fontSize = 16.sp)
                }
            } else {
                Text(
                    text = "Signaling connected",
                    fontSize = 24.sp,
                    color = Color(0xFF00E5A8),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Video rendering will appear here once decoder is fully attached",
                    color = Color.White.copy(alpha = 0.5f)
                )
            }
        }
    }
}

private suspend fun connectToPhone(ip: String, pin: String): Boolean = withContext(Dispatchers.IO) {
    try {
        val offerUrl = URL("http://$ip:8080/offer?pin=$pin")
        val offerConn = offerUrl.openConnection() as HttpURLConnection
        offerConn.connectTimeout = 5000
        offerConn.readTimeout = 5000
        offerConn.requestMethod = "GET"

        if (offerConn.responseCode != 200) {
            Log.e("AetherReceiver", "No offer: ${offerConn.responseCode}")
            return@withContext false
        }

        val offerJson = offerConn.inputStream.bufferedReader().readText()
        val offerSdp = JSONObject(offerJson).optString("sdp")
        Log.i("AetherReceiver", "Got offer length=${offerSdp.length}")
        true
    } catch (e: Exception) {
        Log.e("AetherReceiver", "Connect failed", e)
        false
    }
}
