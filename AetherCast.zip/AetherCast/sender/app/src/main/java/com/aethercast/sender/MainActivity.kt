package com.aethercast.sender

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.aethercast.sender.service.ScreenCaptureService
import com.aethercast.sender.ui.AetherCastApp
import com.aethercast.sender.ui.theme.AetherCastTheme
import com.aethercast.sender.webrtc.CastState
import com.aethercast.sender.webrtc.QualityPreset

class MainActivity : ComponentActivity() {

    private var mediaProjectionResultCode: Int = 0
    private var mediaProjectionData: Intent? = null

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (!allGranted) {
            Toast.makeText(this, "Permissions needed for casting", Toast.LENGTH_LONG).show()
        }
    }

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            mediaProjectionResultCode = result.resultCode
            mediaProjectionData = result.data
            startCastingService()
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNeededPermissions()

        setContent {
            AetherCastTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var castState by remember { mutableStateOf(CastState.IDLE) }
                    var currentPreset by remember { mutableStateOf(QualityPreset.BALANCED) }
                    var pin by remember { mutableStateOf("") }
                    var isAudioEnabled by remember { mutableStateOf(true) }

                    AetherCastApp(
                        castState = castState,
                        currentPreset = currentPreset,
                        pin = pin,
                        isAudioEnabled = isAudioEnabled,
                        onStartCast = {
                            requestScreenCapture()
                        },
                        onStopCast = {
                            stopCastingService()
                            castState = CastState.IDLE
                        },
                        onPresetChange = { preset ->
                            currentPreset = preset
                            // In a full implementation we would send this to the service
                        },
                        onAudioToggle = {
                            isAudioEnabled = !isAudioEnabled
                        },
                        onPinGenerated = { generatedPin ->
                            pin = generatedPin
                        }
                    )
                }
            }
        }
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val toRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(toRequest.toTypedArray())
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun startCastingService() {
        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, mediaProjectionResultCode)
            putExtra(ScreenCaptureService.EXTRA_DATA, mediaProjectionData)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopCastingService() {
        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(intent)
    }
}
