package com.aethercast.sender.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.aethercast.sender.MainActivity
import com.aethercast.sender.R
import com.aethercast.sender.util.NetworkUtils
import com.aethercast.sender.webrtc.CastState
import com.aethercast.sender.webrtc.QualityPreset
import com.aethercast.sender.webrtc.SignalingServer
import com.aethercast.sender.webrtc.WebRtcManager
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.aethercast.sender.START"
        const val ACTION_STOP = "com.aethercast.sender.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val EXTRA_PRESET = "preset"
        const val EXTRA_AUDIO = "audio"

        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "aethercast_channel"
        private const val TAG = "AetherCastService"

        @Volatile var currentState: CastState = CastState.IDLE
        @Volatile var currentPin: String = ""
        @Volatile var localIp: String? = null
    }

    private var webRtcManager: WebRtcManager? = null
    private var signalingServer: SignalingServer? = null
    private val isRunning = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (isRunning.get()) return START_STICKY

                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_DATA)
                }
                val presetName = intent.getStringExtra(EXTRA_PRESET) ?: QualityPreset.BALANCED.name
                val enableAudio = intent.getBooleanExtra(EXTRA_AUDIO, true)
                val preset = try { QualityPreset.valueOf(presetName) } catch (e: Exception) { QualityPreset.BALANCED }

                if (data != null) {
                    startForegroundNotification()
                    startEverything(resultCode, data, preset, enableAudio)
                }
            }
            ACTION_STOP -> {
                stopEverything()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startEverything(resultCode: Int, data: Intent, preset: QualityPreset, enableAudio: Boolean) {
        isRunning.set(true)
        currentState = CastState.CONNECTING

        currentPin = (100000 + Random.nextInt(900000)).toString()
        localIp = NetworkUtils.getLocalIpAddress(this)
        Log.i(TAG, "PIN=$currentPin IP=$localIp")

        signalingServer = SignalingServer(
            onOfferReceived = {},
            onAnswerReceived = { answerSdp ->
                webRtcManager?.setRemoteAnswer(answerSdp)
            },
            onIceCandidate = { cand ->
                // format: mid|index|sdp
                val parts = cand.split("|", limit = 3)
                if (parts.size == 3) {
                    webRtcManager?.addIceCandidate(parts[0], parts[1].toIntOrNull() ?: 0, parts[2])
                }
            }
        )
        signalingServer?.createRoom(currentPin)
        try {
            signalingServer?.start()
            Log.i(TAG, "Signaling on :8080")
        } catch (e: Exception) {
            Log.e(TAG, "Signaling start failed", e)
            currentState = CastState.ERROR
            return
        }

        webRtcManager = WebRtcManager(
            context = this,
            onStateChange = { state ->
                currentState = state
                Log.i(TAG, "State → $state")
                // Update notification with new PIN if needed
            },
            onLocalSdp = { offerSdp ->
                signalingServer?.setOffer(currentPin, offerSdp)
                // Publish offer into the signaling room
                try {
                    val body = JSONObject()
                        .put("pin", currentPin)
                        .put("sdp", offerSdp)
                        .toString()
                    // The SignalingServer stores offers when POSTed.
                    // We simulate the internal store for reliability:
                    Log.i(TAG, "Offer published for PIN $currentPin (len=${offerSdp.length})")
                } catch (e: Exception) {
                    Log.e(TAG, "Publish offer failed", e)
                }
            },
            onIceCandidateReady = { candStr ->
                // Could POST to signaling, but for local we rely on polling from TV
            }
        )
        webRtcManager?.initialize()
        // Small delay so factory is ready
        android.os.Handler(mainLooper).postDelayed({
            webRtcManager?.start(resultCode, data, preset, enableAudio)
        }, 400)
    }

    private fun stopEverything() {
        if (!isRunning.getAndSet(false)) return

        webRtcManager?.stop()
        webRtcManager?.dispose()
        webRtcManager = null

        signalingServer?.stop()
        signalingServer?.destroyRoom(currentPin)
        signalingServer = null

        currentState = CastState.IDLE
        currentPin = ""
        Log.i(TAG, "Stopped")
    }

    private fun startForegroundNotification() {
        createNotificationChannel()

        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AetherCast is casting")
            .setContentText("PIN: $currentPin  •  IP: ${localIp ?: "…"}")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "AetherCast", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopEverything()
        super.onDestroy()
    }
}
