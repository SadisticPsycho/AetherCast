package com.aethercast.sender.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aethercast.sender.webrtc.CastState
import com.aethercast.sender.webrtc.QualityPreset

@Composable
fun AetherCastApp(
    castState: CastState,
    currentPreset: QualityPreset,
    pin: String,
    isAudioEnabled: Boolean,
    onStartCast: () -> Unit,
    onStopCast: () -> Unit,
    onPresetChange: (QualityPreset) -> Unit,
    onAudioToggle: () -> Unit,
    onPinGenerated: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F0F13),
                        Color(0xFF16161F),
                        Color(0xFF0F0F13)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            // Logo / Title
            Text(
                text = "AetherCast",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = Color(0xFF7C5CFF)
            )
            Text(
                text = "Low latency screen sharing",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Status Card
            StatusCard(castState = castState, pin = pin)

            Spacer(modifier = Modifier.height(32.dp))

            // Quality Presets
            Text(
                text = "Quality Preset",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(12.dp))

            QualityPresetRow(
                current = currentPreset,
                onSelect = onPresetChange,
                enabled = castState != CastState.CONNECTING
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Audio Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isAudioEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = null,
                        tint = if (isAudioEnabled) Color(0xFF00E5A8) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Audio Mirroring", color = MaterialTheme.colorScheme.onSurface)
                }
                Switch(
                    checked = isAudioEnabled,
                    onCheckedChange = { onAudioToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF00E5A8)
                    )
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Main Action Button
            Button(
                onClick = {
                    if (castState == CastState.IDLE || castState == CastState.ERROR) {
                        onStartCast()
                    } else {
                        onStopCast()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (castState == CastState.CASTING)
                        Color(0xFFFF4D6A) else Color(0xFF7C5CFF)
                )
            ) {
                Icon(
                    imageVector = if (castState == CastState.CASTING)
                        Icons.Default.Stop else Icons.Default.Cast,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when (castState) {
                        CastState.IDLE -> "Start Casting"
                        CastState.CONNECTING -> "Connecting…"
                        CastState.CASTING -> "Stop Casting"
                        CastState.ERROR -> "Retry"
                    },
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Make sure phone & TV are on the same network\n(or use phone hotspot)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun StatusCard(castState: CastState, pin: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val (icon, title, subtitle, color) = when (castState) {
                CastState.IDLE -> Quadruple(
                    Icons.Default.CastConnected,
                    "Ready to cast",
                    "Tap Start Casting below",
                    Color(0xFF7C5CFF)
                )
                CastState.CONNECTING -> Quadruple(
                    Icons.Default.Sync,
                    "Connecting…",
                    "Waiting for TV",
                    Color(0xFFFFB020)
                )
                CastState.CASTING -> Quadruple(
                    Icons.Default.CheckCircle,
                    "Casting active",
                    if (pin.isNotEmpty()) "PIN: $pin" else "Streaming to TV",
                    Color(0xFF00E5A8)
                )
                CastState.ERROR -> Quadruple(
                    Icons.Default.Error,
                    "Connection failed",
                    "Check network and try again",
                    Color(0xFFFF4D6A)
                )
            }

            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun QualityPresetRow(
    current: QualityPreset,
    onSelect: (QualityPreset) -> Unit,
    enabled: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        QualityPreset.values().forEach { preset ->
            val selected = preset == current
            FilterChip(
                selected = selected,
                onClick = { if (enabled) onSelect(preset) },
                enabled = enabled,
                label = {
                    Text(
                        text = when (preset) {
                            QualityPreset.ULTRA_LOW_LATENCY -> "Ultra Low"
                            QualityPreset.BALANCED -> "Balanced"
                            QualityPreset.HIGH_QUALITY -> "High Q"
                            QualityPreset.CUSTOM -> "Custom"
                        },
                        fontSize = 12.sp
                    )
                },
                leadingIcon = if (selected) {
                    {
                        Icon(
                            imageVector = when (preset) {
                                QualityPreset.ULTRA_LOW_LATENCY -> Icons.Outlined.Speed
                                QualityPreset.HIGH_QUALITY -> Icons.Outlined.HighQuality
                                else -> Icons.Default.Tune
                            },
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else null,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

// Simple helper
private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
