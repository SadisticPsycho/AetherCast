package com.aethercast.sender.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF7C5CFF),
    onPrimary = Color.White,
    secondary = Color(0xFF00E5A8),
    onSecondary = Color.Black,
    background = Color(0xFF0F0F13),
    surface = Color(0xFF1A1A22),
    onBackground = Color(0xFFE8E8ED),
    onSurface = Color(0xFFE8E8ED),
    surfaceVariant = Color(0xFF252530),
    onSurfaceVariant = Color(0xFFB0B0C0)
)

@Composable
fun AetherCastTheme(
    darkTheme: Boolean = true, // Always dark for this app
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),
        content = content
    )
}
