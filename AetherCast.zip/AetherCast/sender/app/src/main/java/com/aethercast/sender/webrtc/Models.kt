package com.aethercast.sender.webrtc

enum class CastState {
    IDLE,
    CONNECTING,
    CASTING,
    ERROR
}

enum class QualityPreset(
    val resolutionHeight: Int,
    val fps: Int,
    val bitrateKbps: Int,
    val displayName: String
) {
    ULTRA_LOW_LATENCY(720, 30, 2500, "Ultra Low Latency"),
    BALANCED(1080, 30, 4500, "Balanced"),
    HIGH_QUALITY(1080, 60, 8000, "High Quality"),
    CUSTOM(1080, 30, 6000, "Custom")
}
