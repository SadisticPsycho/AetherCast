package com.aethercast.sender.webrtc

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import org.webrtc.CapturerObserver
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoFrame
import org.webrtc.VideoSink

/**
 * Bridges MediaProjection / VirtualDisplay into WebRTC as a VideoCapturer.
 * This is the critical piece that makes real screen frames flow into the PeerConnection.
 */
class ScreenCapturer(
    private val context: Context,
    private val resultCode: Int,
    private val data: Intent
) : VideoCapturer {

    private val TAG = "ScreenCapturer"
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var capturerObserver: CapturerObserver? = null
    private var width = 0
    private var height = 0
    private var isDisposed = false

    override fun initialize(
        surfaceTextureHelper: SurfaceTextureHelper?,
        context: Context?,
        capturerObserver: CapturerObserver?
    ) {
        this.surfaceTextureHelper = surfaceTextureHelper
        this.capturerObserver = capturerObserver
    }

    override fun startCapture(width: Int, height: Int, framerate: Int) {
        if (isDisposed) return
        this.width = width
        this.height = height

        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = manager.getMediaProjection(resultCode, data)

        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Log.i(TAG, "MediaProjection stopped")
                stopCapture()
            }
        }, Handler(Looper.getMainLooper()))

        val surface = surfaceTextureHelper?.surfaceTexture
        if (surface == null) {
            Log.e(TAG, "SurfaceTexture is null")
            return
        }

        // Set default buffer size so the texture has correct dimensions
        surfaceTextureHelper?.setTextureSize(width, height)

        val density = context.resources.displayMetrics.densityDpi

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "AetherCast",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            android.view.Surface(surface),
            null, null
        )

        capturerObserver?.onCapturerStarted(true)
        Log.i(TAG, "Screen capture started ${width}x${height}")
    }

    override fun stopCapture() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            mediaProjection?.stop()
            mediaProjection = null
            capturerObserver?.onCapturerStopped()
            Log.i(TAG, "Screen capture stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping capture", e)
        }
    }

    override fun changeCaptureFormat(width: Int, height: Int, framerate: Int) {
        // Optional: recreate VirtualDisplay with new size
    }

    override fun dispose() {
        stopCapture()
        isDisposed = true
    }

    override fun isScreencast(): Boolean = true
}
