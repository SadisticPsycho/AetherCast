package com.aethercast.sender.webrtc

import android.util.Log
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class SignalingServer(
    private val port: Int = 8080,
    private val onOfferReceived: (String) -> Unit,
    private val onAnswerReceived: (String) -> Unit,
    private val onIceCandidate: (String) -> Unit
) : NanoHTTPD(port) {

    private val TAG = "AetherSignaling"
    private val rooms = ConcurrentHashMap<String, Room>()

    data class Room(
        var offer: String? = null,
        var answer: String? = null,
        val candidatesFromPhone: MutableList<String> = mutableListOf(),
        val candidatesFromTv: MutableList<String> = mutableListOf()
    )

    fun createRoom(pin: String) {
        rooms[pin] = Room()
        Log.i(TAG, "Room $pin created")
    }

    fun setOffer(pin: String, sdp: String) {
        rooms.getOrPut(pin) { Room() }.offer = sdp
        Log.i(TAG, "Offer set for $pin")
    }

    fun destroyRoom(pin: String) {
        rooms.remove(pin)
    }

    override fun serve(session: IHTTPSession): Response {
        val uri = session.uri
        val method = session.method

        return try {
            when {
                uri == "/offer" && method == Method.GET -> {
                    val pin = session.parameters["pin"]?.firstOrNull() ?: ""
                    val room = rooms[pin]
                    if (room?.offer != null) {
                        newFixedLengthResponse(
                            Response.Status.OK, "application/json",
                            JSONObject().put("sdp", room.offer).toString()
                        )
                    } else {
                        newFixedLengthResponse(Response.Status.NO_CONTENT, "text/plain", "")
                    }
                }

                uri == "/offer" && method == Method.POST -> {
                    val body = readBody(session)
                    val json = JSONObject(body)
                    val pin = json.getString("pin")
                    val sdp = json.getString("sdp")
                    rooms.getOrPut(pin) { Room() }.offer = sdp
                    onOfferReceived(sdp)
                    newFixedLengthResponse(Response.Status.OK, "text/plain", "OK")
                }

                uri == "/answer" && method == Method.POST -> {
                    val body = readBody(session)
                    val json = JSONObject(body)
                    val pin = json.getString("pin")
                    val sdp = json.getString("sdp")
                    rooms[pin]?.answer = sdp
                    onAnswerReceived(sdp)
                    newFixedLengthResponse(Response.Status.OK, "text/plain", "OK")
                }

                uri == "/answer" && method == Method.GET -> {
                    val pin = session.parameters["pin"]?.firstOrNull() ?: ""
                    val room = rooms[pin]
                    if (room?.answer != null) {
                        newFixedLengthResponse(
                            Response.Status.OK, "application/json",
                            JSONObject().put("sdp", room.answer).toString()
                        )
                    } else {
                        newFixedLengthResponse(Response.Status.NO_CONTENT, "text/plain", "")
                    }
                }

                uri == "/candidate" && method == Method.POST -> {
                    val body = readBody(session)
                    val json = JSONObject(body)
                    val pin = json.getString("pin")
                    val candidate = json.getString("candidate")
                    val from = json.optString("from", "tv")
                    val room = rooms.getOrPut(pin) { Room() }
                    if (from == "phone") {
                        room.candidatesFromPhone.add(candidate)
                    } else {
                        room.candidatesFromTv.add(candidate)
                        onIceCandidate(candidate)
                    }
                    newFixedLengthResponse(Response.Status.OK, "text/plain", "OK")
                }

                uri == "/candidate" && method == Method.GET -> {
                    val pin = session.parameters["pin"]?.firstOrNull() ?: ""
                    val from = session.parameters["from"]?.firstOrNull() ?: "phone"
                    val room = rooms[pin]
                    val list = if (from == "phone") room?.candidatesFromPhone else room?.candidatesFromTv
                    val copy = list?.toList() ?: emptyList()
                    list?.clear()
                    newFixedLengthResponse(
                        Response.Status.OK, "application/json",
                        JSONObject().put("candidates", copy).toString()
                    )
                }

                uri == "/status" -> newFixedLengthResponse(Response.Status.OK, "text/plain", "AetherCast OK")

                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error", e)
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", e.message ?: "error")
        }
    }

    private fun readBody(session: IHTTPSession): String {
        val map = HashMap<String, String>()
        session.parseBody(map)
        return map["postData"] ?: ""
    }
}
