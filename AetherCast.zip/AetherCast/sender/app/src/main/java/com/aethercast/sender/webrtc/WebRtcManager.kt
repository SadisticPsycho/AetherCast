package com.aethercast.sender.webrtc

import android.content.Context
import android.content.Intent
import android.util.Log
import org.webrtc.*
import java.util.concurrent.Executors

class WebRtcManager(
    private val context: Context,
    private val onStateChange: (CastState) -> Unit,
    private val onLocalSdp: (String) -> Unit,
    private val onIceCandidateReady: (String) -> Unit
) {
    private val TAG = "AetherWebRTC"
    private val executor = Executors.newSingleThreadExecutor()

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var eglBase: EglBase? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private var screenCapturer: ScreenCapturer? = null

    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
    )

    fun initialize() {
        executor.execute {
            val options = PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
            PeerConnectionFactory.initialize(options)

            eglBase = EglBase.create()

            val encoderFactory = DefaultVideoEncoderFactory(
                eglBase!!.eglBaseContext,
                true,
                true
            )
            val decoderFactory = DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)

            peerConnectionFactory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(encoderFactory)
                .setVideoDecoderFactory(decoderFactory)
                .createPeerConnectionFactory()

            Log.i(TAG, "WebRTC factory ready")
        }
    }

    fun start(
        resultCode: Int,
        data: Intent,
        preset: QualityPreset,
        enableAudio: Boolean
    ) {
        executor.execute {
            onStateChange(CastState.CONNECTING)

            val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
                sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            }

            peerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    Log.i(TAG, "ICE: $state")
                    when (state) {
                        PeerConnection.IceConnectionState.CONNECTED,
                        PeerConnection.IceConnectionState.COMPLETED -> onStateChange(CastState.CASTING)
                        PeerConnection.IceConnectionState.FAILED,
                        PeerConnection.IceConnectionState.DISCONNECTED -> onStateChange(CastState.ERROR)
                        else -> {}
                    }
                }
                override fun onIceConnectionReceivingChange(receiving: Boolean) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate?.let {
                        val candStr = "${it.sdpMid}|${it.sdpMLineIndex}|${it.sdp}"
                        onIceCandidateReady(candStr)
                    }
                }
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
                override fun onAddStream(stream: MediaStream?) {}
                override fun onRemoveStream(stream: MediaStream?) {}
                override fun onDataChannel(dc: DataChannel?) {}
                override fun onRenegotiationNeeded() {}
                override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
            })

            surfaceTextureHelper = SurfaceTextureHelper.create("AetherCapture", eglBase!!.eglBaseContext)
            videoSource = peerConnectionFactory?.createVideoSource(false)

            screenCapturer = ScreenCapturer(context, resultCode, data)
            screenCapturer?.initialize(surfaceTextureHelper, context, videoSource?.capturerObserver)

            val captureHeight = preset.resolutionHeight
            val captureWidth = (captureHeight * 16 / 9)
            screenCapturer?.startCapture(captureWidth, captureHeight, preset.fps)

            videoTrack = peerConnectionFactory?.createVideoTrack("video0", videoSource)
            videoTrack?.setEnabled(true)
            peerConnection?.addTrack(videoTrack)

            if (enableAudio) {
                val audioConstraints = MediaConstraints()
                audioSource = peerConnectionFactory?.createAudioSource(audioConstraints)
                audioTrack = peerConnectionFactory?.createAudioTrack("audio0", audioSource)
                audioTrack?.setEnabled(true)
                peerConnection?.addTrack(audioTrack)
            }

            val constraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            }

            peerConnection?.createOffer(object : SdpObserver {
                override fun onCreateSuccess(sdp: SessionDescription?) {
                    peerConnection?.setLocalDescription(object : SdpObserver {
                        override fun onSetSuccess() {
                            sdp?.description?.let { onLocalSdp(it) }
                            Log.i(TAG, "Offer ready")
                        }
                        override fun onSetFailure(error: String?) {
                            Log.e(TAG, "setLocal failed: $error")
                            onStateChange(CastState.ERROR)
                        }
                        override fun onCreateSuccess(p0: SessionDescription?) {}
                        override fun onCreateFailure(p0: String?) {}
                    }, sdp)
                }
                override fun onSetSuccess() {}
                override fun onCreateFailure(error: String?) {
                    Log.e(TAG, "createOffer failed: $error")
                    onStateChange(CastState.ERROR)
                }
                override fun onSetFailure(p0: String?) {}
            }, constraints)
        }
    }

    fun setRemoteAnswer(sdp: String) {
        executor.execute {
            val answer = SessionDescription(SessionDescription.Type.ANSWER, sdp)
            peerConnection?.setRemoteDescription(object : SdpObserver {
                override fun onSetSuccess() { Log.i(TAG, "Answer applied") }
                override fun onSetFailure(error: String?) { Log.e(TAG, "Answer failed: $error") }
                override fun onCreateSuccess(p0: SessionDescription?) {}
                override fun onCreateFailure(p0: String?) {}
            }, answer)
        }
    }

    fun addIceCandidate(mid: String, index: Int, sdp: String) {
        executor.execute {
            try {
                peerConnection?.addIceCandidate(IceCandidate(mid, index, sdp))
            } catch (e: Exception) {
                Log.w(TAG, "ICE add failed", e)
            }
        }
    }

    fun stop() {
        executor.execute {
            try {
                screenCapturer?.stopCapture()
                screenCapturer?.dispose()
                screenCapturer = null
                videoTrack?.dispose()
                audioTrack?.dispose()
                videoSource?.dispose()
                audioSource?.dispose()
                surfaceTextureHelper?.dispose()
                peerConnection?.close()
                peerConnection?.dispose()
                peerConnection = null
                onStateChange(CastState.IDLE)
                Log.i(TAG, "Stopped")
            } catch (e: Exception) {
                Log.e(TAG, "Stop error", e)
            }
        }
    }

    fun dispose() {
        stop()
        executor.execute {
            peerConnectionFactory?.dispose()
            peerConnectionFactory = null
            eglBase?.release()
            eglBase = null
        }
    }
}
